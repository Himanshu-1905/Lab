package com.anudip.theater;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TheaterMain {
    public static void main(String[] args) {
        SessionFactory factory = new Configuration().configure().buildSessionFactory();

        Theater theater = new Theater("Forrest Gump");
        Theater theater2 = new Theater("The Secret Life Of Walter Mitty");

        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        session.persist(theater);
        session.persist(theater2);
        tx.commit();
        session.close();
    }
}