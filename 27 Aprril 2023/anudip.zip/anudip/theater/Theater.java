package com.anudip.theater;

import jakarta.persistence.*;

@Entity
public class Theater {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @Column(name = "movie_name")
    private String movie;

    public Theater(int id, String movie) {
        this.id = id;
        this.movie = movie;
    }

    public Theater(String movie) {
        this.movie = movie;
    }

    public Theater() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }
}
