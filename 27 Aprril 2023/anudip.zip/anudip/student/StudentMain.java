package com.anudip.student;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentMain {
    public static void main(String[] args) {
        SessionFactory factory = new Configuration().configure().buildSessionFactory();

        Student s = new Student();
        s.setName("Krish");
        IdCard idCard = new IdCard(1230, s);
        s.setIdCard(idCard);

        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        session.persist(s);
        session.persist(idCard);

        tx.commit();
        session.close();
    }
}