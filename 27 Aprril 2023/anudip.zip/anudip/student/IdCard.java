package com.anudip.student;

import jakarta.persistence.*;

@Entity
public class IdCard {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int card_id;
    private int card_number;
    @OneToOne(mappedBy = "idCard")
    private Student student;

    public IdCard(int card_id, int card_number, Student student) {
        this.card_id = card_id;
        this.card_number = card_number;
        this.student = student;
    }

    public IdCard(int card_number, Student student) {
        this.card_number = card_number;
        this.student = student;
    }

    public IdCard() {
    }

    public int getCard_id() {
        return card_id;
    }

    public void setCard_id(int card_id) {
        this.card_id = card_id;
    }

    public int getCard_number() {
        return card_number;
    }

    public void setCard_number(int card_number) {
        this.card_number = card_number;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
}
