package com.anudip.student;

import jakarta.persistence.*;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int stu_id;
    private String name;
    @OneToOne
    private IdCard idCard;

    public Student(int stu_id, String name, IdCard idCard) {
        this.stu_id = stu_id;
        this.name = name;
        this.idCard = idCard;
    }

    public Student(String name, IdCard idCard) {
        this.name = name;
        this.idCard = idCard;
    }

    public Student() {
    }

    public int getStu_id() {
        return stu_id;
    }

    public void setStu_id(int stu_id) {
        this.stu_id = stu_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public IdCard getIdCard() {
        return idCard;
    }

    public void setIdCard(IdCard idCard) {
        this.idCard = idCard;
    }
}
